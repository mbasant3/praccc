// import React from "react";
// import { createRoot } from "react-dom/client";
// import {
//   createBrowserRouter,
//   RouterProvider,
//   Outlet,
// } from "react-router-dom";
// import About from "./About";
// import Home from "./Home";
// import Interest from "./Interest";
// import Navbar from "./nav";
// import "./App.css";

// const AppLayout = () => (
//   <>
//     <Navbar />
//     <Outlet />
//   </>
// );

// const router = createBrowserRouter([
//   {
//     element: <AppLayout />,
//     children: [
//       {
//         path: "/",
//         element: <Home />,
//       },
//       {
//         path: "About",
//         element: <About />,
//       },
//       {
//         path: "Interest",
//         element: <Interest />,
//       },
//     ],
//   },
// ]);

// createRoot(document.getElementById("root")).render(
//   <RouterProvider router={router} />
// );

import App from "./App";
import ReactDOM from 'react-dom/client';
import { BrowserRouter } from "react-router-dom";



const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(
<BrowserRouter>
  <App />
  </BrowserRouter>);