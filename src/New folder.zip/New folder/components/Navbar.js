import {Component} from "react";

class Navbar extends Component{
    render(){
        return(
            <nav className="NavbarItems">
                <ul>
                    <li><a href="/">Home</a></li>
                    <li></li>
                </ul>
            </nav>
        );
    }
}

export default Navbar;