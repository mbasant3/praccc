import React from "react";

function Interest() {
  return (
    <div className="interest">
      <h1>Interest</h1>
    </div>
  );
}

export default Interest;
