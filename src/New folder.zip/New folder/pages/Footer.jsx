import React from "react";
// import "./Footer.css";

function Footer() {
  return (
    <div className="main-footer">
        <div className="container">
            <div className="row">
                <div className="col">
                    <h1>Address</h1>
                    <ul className="unstyled">
                        <li>Kranti Nagar, Lokhandwala</li>
                        <li>Kandiavli-(East)</li>
                        <li>Mumbai-400101</li>
                    </ul>
                </div>
                <div className="col">
                    <ul>
                        <li>Mobile No</li>
                    </ul>
                </div>
            </div>
        </div>
      <h1>footer</h1>
    </div>
  );
}

export default Footer;
